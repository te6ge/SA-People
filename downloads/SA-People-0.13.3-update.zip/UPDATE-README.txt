SA People 0.13.3 beta — manual update

Requires an existing full SA People installation on GTA SA PC 1.0 US.
Close the game. Back up SA-People/people.dat and your saves. Copy the ZIP contents
into the folder containing gta_sa.exe and replace matching files. Do not delete
your SA-People folder. No EXE, settings file or player archive is included here.

For a first installation, install the full package from
https://github.com/te6ge/SA-People/releases before applying this update.

Source and English update notes: https://github.com/te6ge/SA-People
